import instance from '@/http/http';

function apiIndex() {

    return new Promise((resolve, reject) => {

        instance.get()

    })

}

export {apiIndex}